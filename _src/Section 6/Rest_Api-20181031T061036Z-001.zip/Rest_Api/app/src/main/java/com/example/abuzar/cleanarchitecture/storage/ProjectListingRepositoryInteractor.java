package com.example.abuzar.cleanarchitecture.storage;

import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;

import java.util.List;

public interface ProjectListingRepositoryInteractor {

    void onProjectListRetereived(List<ProjectModel> projectLists);

    void onError(String message);
}
