package com.example.abuzar.cleanarchitecture.presentation.presenters.impl;


import com.example.abuzar.cleanarchitecture.businesslayer.interactors.ProjectListingInteractor;
import com.example.abuzar.cleanarchitecture.businesslayer.interactors.impl.ProjectListingInteractorImpl;
import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.businesslayer.repository.ProjectRepository;
import com.example.abuzar.cleanarchitecture.presentation.presenters.MainPresenter;

import java.util.List;

public class MainPresenterImpl implements MainPresenter, ProjectListingInteractor.Callback {

    private MainPresenter.View mView;
    private ProjectRepository mProjectRepository;

    public MainPresenterImpl(View view, ProjectRepository mProjectRepository) {
        mView = view;
        this.mProjectRepository = mProjectRepository;
    }

    @Override
    public void resume() {
        mView.showProgress();
        // initialize the interactor
        ProjectListingInteractor interactor = new ProjectListingInteractorImpl(
                this,
                mProjectRepository);

    }

    @Override
    public void onError(String message) {
        mView.showError(message);
    }

    @Override
    public void onProjectListRetrieved(List<ProjectModel> projectModelList) {
        mView.hideProgress();
        mView.displayProjectList(projectModelList);

    }

    @Override
    public void onProjectListingFailed(String error) {
        mView.hideProgress();
        onError(error);

    }
}
