package com.example.abuzar.cleanarchitecture.di.component;

import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.di.module.ProjectModule;
import com.example.abuzar.cleanarchitecture.di.scope.PerActivity;
import com.example.abuzar.cleanarchitecture.presentation.ui.activities.MainActivity;
import com.example.abuzar.cleanarchitecture.di.module.NetworkModule;

import dagger.Component;

/**
 * Created by abuzar.aslam on 3/18/2018.
 */

@PerActivity
@Component(modules = ProjectModule.class, dependencies = ApplicationComponent.class)
public interface ListComponent {

    void inject(MainActivity activity);

}
