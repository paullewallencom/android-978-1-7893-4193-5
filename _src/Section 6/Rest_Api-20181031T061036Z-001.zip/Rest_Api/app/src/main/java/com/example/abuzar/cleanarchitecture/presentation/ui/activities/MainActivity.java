package com.example.abuzar.cleanarchitecture.presentation.ui.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

import com.example.abuzar.cleanarchitecture.R;
import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.di.component.DaggerListComponent;
import com.example.abuzar.cleanarchitecture.di.module.ProjectModule;
import com.example.abuzar.cleanarchitecture.presentation.base.BaseActivity;
import com.example.abuzar.cleanarchitecture.presentation.presenters.MainPresenter;
import com.example.abuzar.cleanarchitecture.presentation.presenters.impl.MainPresenterImpl;
import com.example.abuzar.cleanarchitecture.presentation.ui.ProjectAdapter;
import com.example.abuzar.cleanarchitecture.storage.ProjectListingRepository;

import java.util.List;

import javax.inject.Inject;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends BaseActivity implements MainPresenter.View {


    @Inject
    ProjectListingRepository projectListingRepository;

    @BindView(R.id.project_list)
    ListView projectListView;

    private MainPresenter mPresenter;
    ProjectAdapter projectAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        projectAdapter = new ProjectAdapter(this);
        projectListView.setAdapter(projectAdapter);
        // create a presenter for this view
        mPresenter = new MainPresenterImpl(
                this,
                projectListingRepository);
    }


    @Override
    protected void resolveDaggerDependency() {

        DaggerListComponent.builder()
                .applicationComponent(getApplicationComponent())
                .projectModule(new ProjectModule())
                .build().inject(this);
    }

    @Override
    protected int getContentView() {
        return R.layout.activity_main;
    }

    @Override
    protected void onResume() {
        super.onResume();
        mPresenter.resume();
    }

    @Override
    public void showProgress() {
        Toast.makeText(this, "Show Progress Bar", Toast.LENGTH_LONG).show();
//        mWelcomeTextView.setText("Retrieving...");
    }

    @Override
    public void hideProgress() {
        Toast.makeText(this, "Hide Progress Bar!", Toast.LENGTH_LONG).show();
    }

    @Override
    public void showError(String message) {
        Toast.makeText(this, "ShowError", Toast.LENGTH_LONG).show();
//        mWelcomeTextView.setText(message);
    }

    @Override
    public void displayProjectList(List<ProjectModel> projectModelList) {

        projectAdapter.addItems(projectModelList);
    }
}
