package com.example.abuzar.cleanarchitecture.di.module;

import com.example.abuzar.cleanarchitecture.di.scope.PerActivity;
import com.example.abuzar.cleanarchitecture.storage.api.ProjectApiService;

import dagger.Module;
import dagger.Provides;
import retrofit2.Retrofit;

/**
 * Created by abuzar.aslam on 3/18/2018.
 */

@Module
public class ProjectModule {


    public ProjectModule()
    {
    }

    @PerActivity
    @Provides
    ProjectApiService provideProjectApiService(Retrofit retrofit)
    {
        return retrofit.create(ProjectApiService.class);
    }

}
