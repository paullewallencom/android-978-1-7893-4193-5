package com.example.abuzar.cleanarchitecture.presentation.base;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.CallSuper;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.abuzar.cleanarchitecture.application.ProjectApplication;
import com.example.abuzar.cleanarchitecture.di.component.ApplicationComponent;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by abuzar.aslam on 3/17/2018.
 */

public abstract class BaseActivity extends AppCompatActivity {

    Unbinder unbinder;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getContentView());
        unbinder = ButterKnife.bind(this);
        onViewReady(savedInstanceState, getIntent());

    }

    @CallSuper
    protected void onViewReady(Bundle savedInstanceState, Intent intent) {
        // Tobe used by child activity
        resolveDaggerDependency();

    }

    protected ApplicationComponent getApplicationComponent() {
        return ((ProjectApplication) getApplication()).getApplicationComponent();
    }

    protected void resolveDaggerDependency() {

    }

    protected abstract int getContentView();

    @Override
    protected void onDestroy() {
        unbinder.unbind();
        super.onDestroy();
    }
}
