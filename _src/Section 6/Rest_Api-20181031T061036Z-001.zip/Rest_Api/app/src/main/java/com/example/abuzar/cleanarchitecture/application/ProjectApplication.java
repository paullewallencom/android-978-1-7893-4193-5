package com.example.abuzar.cleanarchitecture.application;

import android.app.Application;

import com.example.abuzar.cleanarchitecture.di.component.ApplicationComponent;
import com.example.abuzar.cleanarchitecture.di.component.DaggerApplicationComponent;
import com.example.abuzar.cleanarchitecture.di.module.NetworkModule;

/**
 * Created by abuzar.aslam on 3/17/2018.
 */

public class ProjectApplication extends Application {

    private ApplicationComponent applicationComponent;

    @Override
    public void onCreate() {

        super.onCreate();
        initializeApplicationComponent();
    }

    private void initializeApplicationComponent() {

       applicationComponent= DaggerApplicationComponent.builder()
               .networkModule(new NetworkModule(this,"http://192.168.43.248:8080/ProjectList/rest/"))
               .build();
    }


    public ApplicationComponent getApplicationComponent()
    {
        return applicationComponent;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}
