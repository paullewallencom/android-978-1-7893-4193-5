package com.example.abuzar.cleanarchitecture.storage;

import com.example.abuzar.cleanarchitecture.businesslayer.interactors.impl.ProjectListingInteractorImpl;
import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.businesslayer.repository.ProjectRepository;
import com.example.abuzar.cleanarchitecture.storage.api.ProjectApiService;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


public class ProjectListingRepository implements ProjectRepository, Observer<ProjectModel> {


    List<ProjectModel> projectModelList = new ArrayList<>();
    ProjectListingRepositoryInteractor projectListingRepositoryInteractor;

    @Inject
    protected ProjectApiService projectApiService;


    @Inject
    public ProjectListingRepository() {
    }

    @Override
    public void getProjectListing(ProjectListingRepositoryInteractor projectListingRepositoryInteractor) {

        this.projectListingRepositoryInteractor = projectListingRepositoryInteractor;
        Observable<ProjectModel> projectModelObservable = projectApiService.getProjectList();
        subscribe(projectModelObservable, this);
    }

    protected <T> void subscribe(Observable<T> observable, Observer<T> observer) {
        observable.subscribeOn(Schedulers.newThread())
                .toSingle()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(observer);
    }


    @Override
    public void onCompleted() {
        projectListingRepositoryInteractor.onProjectListRetereived(projectModelList);
    }

    @Override
    public void onError(Throwable e) {
        projectListingRepositoryInteractor.onError(e.getMessage());
    }

    @Override
    public void onNext(ProjectModel projectModel) {
        projectModelList.add(projectModel);
    }
}
