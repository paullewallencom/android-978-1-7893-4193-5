package com.example.abuzar.cleanarchitecture.presentation.presenters;


import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.presentation.presenters.base.BasePresenter;
import com.example.abuzar.cleanarchitecture.presentation.ui.BaseView;

import java.util.List;

public interface MainPresenter extends BasePresenter {

    interface View extends BaseView {
        void displayProjectList(List<ProjectModel> projectModelList);
    }
}
