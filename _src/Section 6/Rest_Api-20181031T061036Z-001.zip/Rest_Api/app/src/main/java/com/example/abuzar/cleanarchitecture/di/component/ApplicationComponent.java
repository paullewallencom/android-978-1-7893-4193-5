package com.example.abuzar.cleanarchitecture.di.component;

import android.content.Context;

import com.example.abuzar.cleanarchitecture.di.module.NetworkModule;

import javax.inject.Singleton;

import dagger.Component;
import retrofit2.Retrofit;

/**
 * Created by abuzar.aslam on 3/18/2018.
 */

@Singleton
@Component(modules = NetworkModule.class)
public interface ApplicationComponent {

    Retrofit exposeRetrofit();

    Context exposeContext();

}
