package com.example.abuzar.cleanarchitecture.businesslayer.interactors.impl;

import com.example.abuzar.cleanarchitecture.businesslayer.interactors.ProjectListingInteractor;
import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.businesslayer.repository.ProjectRepository;
import com.example.abuzar.cleanarchitecture.storage.ProjectListingRepositoryInteractor;

import java.util.List;


public class ProjectListingInteractorImpl implements ProjectListingInteractor, ProjectListingRepositoryInteractor {

    private ProjectListingInteractor.Callback mCallback;
    private ProjectRepository mProjectRepository;

    public ProjectListingInteractorImpl(
            Callback callback, ProjectRepository messageRepository) {
        mCallback = callback;
        mProjectRepository = messageRepository;
        getData();
    }

    private void notifyError(String message) {


        mCallback.onProjectListingFailed(message);
    }

    private void postMessage(List<ProjectModel> msg) {
        mCallback.onProjectListRetrieved(msg);
    }


    public void getData() {
        // retrieve the message
        mProjectRepository.getProjectListing(this);


    }

    @Override
    public void onProjectListRetereived(List<ProjectModel> projectLists) {
        if (projectLists == null || projectLists.size() == 0) {

            notifyError("List is empty");

            return;
        }
        postMessage(projectLists);

    }

    @Override
    public void onError(String message) {
        notifyError(message);
    }
}
