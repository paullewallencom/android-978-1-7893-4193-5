package com.example.abuzar.cleanarchitecture.storage.api;

import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;

import retrofit2.http.GET;
import rx.Observable;

/**
 * Created by abuzar.aslam on 3/18/2018.
 */

public interface ProjectApiService {

    //With RxJava
    @GET("/list")
    Observable<ProjectModel> getProjectList();
}
