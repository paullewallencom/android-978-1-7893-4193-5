package com.example.abuzar.cleanarchitecture.businesslayer.repository;

import com.example.abuzar.cleanarchitecture.businesslayer.interactors.impl.ProjectListingInteractorImpl;
import com.example.abuzar.cleanarchitecture.businesslayer.model.ProjectModel;
import com.example.abuzar.cleanarchitecture.storage.ProjectListingRepositoryInteractor;

import java.util.List;


public interface ProjectRepository {
    void getProjectListing(ProjectListingRepositoryInteractor projectListingInteractor);
}
