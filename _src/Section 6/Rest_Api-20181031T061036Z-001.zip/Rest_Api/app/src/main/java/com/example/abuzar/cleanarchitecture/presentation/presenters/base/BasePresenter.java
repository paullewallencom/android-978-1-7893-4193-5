package com.example.abuzar.cleanarchitecture.presentation.presenters.base;

public interface BasePresenter {

    void resume();

    void onError(String message);
}
